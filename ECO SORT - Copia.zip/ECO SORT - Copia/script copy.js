let pontos = 0 
let vidas = 3
let jogoAtivo = true
let tempo = 60
let jogostart = false
let nomeAtual = ""
let transicaoCuriosidades = null


const somAcerto = new Audio("SONS/acertou-pergunta.mp3")
const somErro = new Audio("SONS/sonic-error-sound.mp3")

const listaObjetos = [
    { nome: "Pilha", tipo: "baterias", icone: "streamline-plump-color:battery-charging" },
    { nome: "Celular", tipo: "eletronicos", icone: "streamline-plump-color:threat-phone" },
    { nome: "Lampada", tipo: "lamps", icone: "streamline-plump-color:lightbulb" },
    { nome: "Cabo USB", tipo: "cabsetc", icone: "streamline-plump-color:usb-port" },
    { nome: "Mouse", tipo: "eletronicos", icone: "streamline-plump-color:mouse-wireless" },
    { nome: "Teclado", tipo: "eletronicos", icone: "streamline-plump-color:keyboard" },
    { nome: "Bateria de celular", tipo: "baterias", icone: "streamline-plump-color:battery-low-3" },
    { nome: "Cabo de Rede", tipo: "cabsetc", icone: "mdi:ethernet-cable" },
]

const pilha = document.getElementById("Pilha")
const batlixeira = document.getElementById("batlixeira")
const lixeiras = document.querySelectorAll("#lixeiras div")
const arealixo = document.getElementById("arealixo")
const pnts = document.getElementById("pnts")
const vidasTexto = document.getElementById("vidas")
const tempoTexto = document.getElementById("tempo")
const pontuacaoFinal = document.getElementById("pontuacaoFinal")
const feedback = document.getElementById("feedback")
const pontuacaoAnimacao = document.getElementById("pontuacaoAnimacao")


const botaoAgain = document.getElementById("botaoAgain")
botaoAgain.addEventListener("click", function() {
    pontos = 0
    clearTimeout(transicaoCuriosidades)
    pnts.textContent = "Pontos: " + pontos
    vidas = 3
    vidasTexto.textContent = "Vidas: " + vidas
    tempo = 60 
    tempoTexto.textContent = "Tempo: " + tempo
    jogoAtivo = true
    jogostart = false

    telaGameOver.style.display = "flex"
    telaJogo.style.display = "block"
    botaocomeçar.style.display = "block"

}) 

const botaoVoltar = document.getElementById("botaoVoltar")
    botaoVoltar.addEventListener("click", function() {
        telaGameOver.style.display = "none"
        telaInicial.style.display = "flex"
    })

    

const telaInicial = document.getElementById("telaInicial")
const telaJogo = document.getElementById("telaJogo")
const telaNome = document.getElementById("telaNome")
const nomeJogador = document.getElementById("nomeJogador")
const botaoNome = document.getElementById("botaoNome")

nomeJogador.addEventListener("input", function() {
    nomeJogador.value = nomeJogador.value.toUpperCase()
})

const telaRanking = document.getElementById("telaRanking")
const listaRanking = document.getElementById("listaRanking")
const botaoVoltarRanking = document.getElementById("botaoVoltarRanking")
const telaGameOver = document.getElementById("telaGameOver")
const telaCuriosidades = document.getElementById("telaCuriosidades")
const botaoContinuar = document.getElementById("botaoContinuar")
const botaoCuriosidades = document.getElementById("botaoCuriosidades")
const telaVoltarJgr = document.getElementById("telaVoltarJgr")
const botaoVoltarJgr = document.getElementById("voltarJgr")

botaoVoltarJgr.addEventListener("click", function() {
    telaVoltarJgr.style.display = "none"
    telaInicial.style.display = "flex"
})

const botaocomeçar = document.getElementById("botcmcr")
botaocomeçar.addEventListener("click", function() {
    jogostart = true
    botaocomeçar.style.display = "none"

    somAcerto.volume = 1
    somErro.volume = 1

    somAcerto.load()
    somErro.load()

    console.log("JOGO COMEÇOU", jogostart)
})

const botaoJogar = document.getElementById("botJogar")

botaoJogar.addEventListener("click", function() {

    telaInicial.style.display = "none"
    telaNome.style.display = "flex"

    nomeJogador.value = ""
    nomeJogador.focus()
})

botaoNome.addEventListener("click", function() {

    const nome = nomeJogador.value.trim()

    if (nome === "") {
        nomeJogador.focus()
        return

        
    }

        nomeAtual = nome.toUpperCase()

    telaNome.style.display = "none"
    telaJogo.style.display = "block"
})


const comoJogar = document.getElementById("comoJogar")

comoJogar.addEventListener("click", function() {
    telaInicial.style.display = "none"
    telaVoltarJgr.style.display = "flex"
})
   
function finalizarJogo() {
    jogoAtivo = false
    salvarRecorde()

    telaJogo.style.display = "none"
    telaGameOver.style.display = "flex"

    pontuacaoFinal.textContent = "Pontos: " + pontos

    clearTimeout(transicaoCuriosidades)

    transicaoCuriosidades = setTimeout(function() {
        telaGameOver.style.display = "none"
        telaCuriosidades.style.display = "flex"
    }, 3000)
}

    function diminuirTempo() {

        if (!jogoAtivo || !jogostart) {
            return
        }

        tempo = tempo - 1
        tempoTexto.textContent = "Tempo: " + tempo

            if (tempo <= 0) {
                finalizarJogo()
            }
    }

    setInterval(diminuirTempo, 1000)

function spawnObjeto() {
    const objetoEscolhido = listaObjetos[Math.floor(Math.random() * listaObjetos.length)]

    const elemento = document.createElement("div")
    elemento.classList.add("objeto")
    elemento.dataset.tipo = objetoEscolhido.tipo
    elemento.draggable = true
    elemento.id = "objeto-" + Date.now()

    const icone = document.createElement("iconify-icon")
    icone.setAttribute("icon", objetoEscolhido.icone)
    icone.classList.add("icone")

    elemento.appendChild(icone)

    arealixo.appendChild(elemento)

       elemento.addEventListener("dragstart", arrastar)
}

const objetos = document.querySelectorAll('[draggable="true"]')

objetos.forEach(function(objeto) {
    objeto.addEventListener("dragstart", arrastar)
})


lixeiras.forEach(function(lixeira) {

    lixeira.addEventListener("dragover", function(event) {
        event.preventDefault()
    })

    lixeira.addEventListener("drop", function(event) {

        if (!jogoAtivo || !jogostart) {
            return
        }

        const objeto = event.dataTransfer.getData("obj")
        const elemento = document.getElementById(objeto)

        const tipoObjeto = elemento.dataset.tipo
        const tipoLixeira = lixeira.dataset.tipo

        if (tipoObjeto === tipoLixeira) {

        lixeira.classList.remove("lixeira-acerto")
        void lixeira.offsetWidth
        lixeira.classList.add("lixeira-acerto")

            pontos = pontos + 50

            pnts.textContent = "Pontos: " + pontos
            pontuacaoAnimacao.textContent = "+50"
            pontuacaoAnimacao.classList.remove("mostrar")
            void pontuacaoAnimacao.offsetWidth
            pontuacaoAnimacao.classList.add("mostrar")
            somAcerto.currentTime = 0
            somAcerto.play()

            feedback.textContent = ""


        setTimeout(function() {
            feedback.style.transform = "scale(1)"
                }, 200)

            elemento.remove()

            setTimeout(function() {
                spawnObjeto()
            }, 1500)

            console.log("DAMN IT")

        } else {

            vidas = vidas - 1

            if (vidas < 0) {
                vidas = 0
            }

            vidasTexto.textContent = "Vidas: " + vidas

            somErro.currentTime = 0
            somErro.play()

            feedback.textContent = ""

            elemento.classList.add("erro")

            setTimeout(function() {
                elemento.classList.remove("erro")
            }, 450)

            

setTimeout(function() {
    feedback.style.transform = "scale(1)"
}, 200)

           if (vidas <= 0) {
                finalizarJogo()
                return
            }
            console.log("NAH, I'D WIN")
        }
    })
})


function arrastar(event) {
    event.dataTransfer.effectAllowed = "move"
    event.dataTransfer.setData("obj", event.currentTarget.id)
}


spawnObjeto()

let objetoSelecionado = null

arealixo.addEventListener("click", function(event) {

    const objeto = event.target.closest(".objeto")

    if (!objeto) {
        return
    }

    if (!jogoAtivo || !jogostart) {
        return
    }

    if (objetoSelecionado) {
        objetoSelecionado.classList.remove("selecionado")
    }

    objetoSelecionado = objeto

    objetoSelecionado.classList.add("selecionado")

    feedback.textContent = "👆 Agora escolha uma lixeira!"
})


lixeiras.forEach(function(lixeira) {

    lixeira.addEventListener("click", function() {

        if (!jogoAtivo || !jogostart) {
            return
        }

        if (!objetoSelecionado) {
            return
        }

        const tipoObjeto = objetoSelecionado.dataset.tipo
        const tipoLixeira = lixeira.dataset.tipo

        if (tipoObjeto === tipoLixeira) {

            lixeira.classList.remove("lixeira-acerto")
            void lixeira.offsetWidth
            lixeira.classList.add("lixeira-acerto")

            pontos = pontos + 50

            pnts.textContent = "Pontos: " + pontos
            pontuacaoAnimacao.textContent = "+50"
            pontuacaoAnimacao.classList.remove("mostrar")
            void pontuacaoAnimacao.offsetWidth
            pontuacaoAnimacao.classList.add("mostrar")

            feedback.textContent = ""
            somAcerto.currentTime = 0
            somAcerto.play()
        
            objetoSelecionado.remove()
            objetoSelecionado = null

            spawnObjeto()

        } else {

            vidas = vidas - 1

            if (vidas < 0) {
                vidas = 0
            }

            vidasTexto.textContent = "Vidas: " + vidas

            feedback.textContent = "⚠️ OPS! ERROU! -1 VIDA"

            somErro.currentTime = 0
            somErro.play()

            const objetoComErro = objetoSelecionado

            objetoComErro.classList.add("erro")

            setTimeout(function() {
                objetoComErro.classList.remove("erro")
            }, 450)

            objetoComErro.classList.remove("selecionado")
            objetoSelecionado = null

            if (vidas <= 0) {
                finalizarJogo()
            }
        }
    })
})

function mostrarCuriosidades() {

    telaGameOver.style.display = "none"
    telaCuriosidades.style.display = "flex"

}

botaoContinuar.addEventListener("click", function() {

    telaCuriosidades.style.display = "none"
    telaInicial.style.display = "flex"

})

botaoCuriosidades.addEventListener("click", function() {

    telaGameOver.style.display = "none"
    telaCuriosidades.style.display = "flex"

})  

function salvarRecorde() {

    let ranking = JSON.parse(localStorage.getItem("ecoSortRanking")) || []

    const jogadorExistente = ranking.find(function(jogador) {
        return jogador.nome.toUpperCase() === nomeAtual.toUpperCase()
    })

    if (jogadorExistente) {

        if (pontos > jogadorExistente.pontos) {
            jogadorExistente.pontos = pontos
        }

        jogadorExistente.nome = nomeAtual

    } else {

        ranking.push({
            nome: nomeAtual,
            pontos: pontos
        })
    }

    ranking.sort(function(a, b) {
        return b.pontos - a.pontos
    })

    localStorage.setItem("ecoSortRanking", JSON.stringify(ranking))
}


function mostrarRanking() {

    telaInicial.style.display = "none"
    telaRanking.style.display = "flex"

    listaRanking.innerHTML = ""

    let ranking = JSON.parse(localStorage.getItem("ecoSortRanking")) || []

    if (ranking.length === 0) {

        listaRanking.innerHTML =
            '<div class="ranking-vazio">Ainda não existem pontuações!</div>'

        return
    }

    ranking.sort(function(a, b) {
        return b.pontos - a.pontos
    })

    ranking.forEach(function(jogador, indice) {

        const item = document.createElement("div")
        item.classList.add("item-ranking")

        let medalha = ""

        if (indice === 0) {
            medalha = "🥇"
        } else if (indice === 1) {
            medalha = "🥈"
        } else if (indice === 2) {
            medalha = "🥉"
        } else {
            medalha = (indice + 1) + "º"
        }

        item.innerHTML = `
            <span class="posicao-ranking">${medalha}</span>
            <span class="nome-ranking">${jogador.nome}</span>
            <span class="pontos-ranking">${jogador.pontos}</span>
        `

        listaRanking.appendChild(item)
    })
}

const botaoRanking = document.createElement("button")

botaoRanking.textContent = "🏆 RANKING"

botaoRanking.addEventListener("click", mostrarRanking)

telaInicial.appendChild(botaoRanking)

botaoVoltarRanking.addEventListener("click", function() {

    telaRanking.style.display = "none"
    telaInicial.style.display = "flex"

})